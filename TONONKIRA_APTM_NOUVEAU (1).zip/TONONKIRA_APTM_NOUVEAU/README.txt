TONONKIRA A.P.T.M. - SOURCE ANDROID VAOVAO

Fampandehanana:
1. Alefaso ao amin'ny GitHub repository ny votoatin'ity dossier ity.
2. Sokafy Actions > Build TONONKIRA APTM APK > Run workflow.
3. Rehefa vita ny build, alaivo ny artifact TONONKIRA-APTM-APK.

Efa ao amin'ity kinova fototra ity:
- Fitahirizana tononkira ao anaty finday (offline)
- Fanampiana sy fanovana hira
- Import rakitra TXT
- Projection fullscreen
- Fampidirana sy playback audio

Mbola tsy tafiditra amin'ity kinova fototra ity:
- Import PDF sy Word
- OCR avy amin'ny sary
- Fampidirana ny logo ofisialy (miandry ny sary avy amin'ny tompony)

Kinova fototra vaovao izy ity, fa tsy APK efa voa-build. Ny APK dia avoakan'ny GitHub Actions.
