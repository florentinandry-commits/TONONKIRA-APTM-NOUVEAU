package mg.aptm.tononkira;

public class Song {
    public String title;
    public String lyrics;
    public String audioUri;
    public Song(String title, String lyrics, String audioUri) {
        this.title = title;
        this.lyrics = lyrics;
        this.audioUri = audioUri;
    }
}
