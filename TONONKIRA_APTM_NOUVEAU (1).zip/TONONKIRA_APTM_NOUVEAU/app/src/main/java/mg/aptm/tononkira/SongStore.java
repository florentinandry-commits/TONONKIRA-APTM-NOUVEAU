package mg.aptm.tononkira;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class SongStore {
    private static final String PREF = "aptm_songs";
    private static final String KEY = "items";
    public static ArrayList<Song> load(Context c) {
        ArrayList<Song> out = new ArrayList<>();
        try {
            String raw = c.getSharedPreferences(PREF, 0).getString(KEY, "[]");
            JSONArray a = new JSONArray(raw);
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                out.add(new Song(o.optString("title"), o.optString("lyrics"), o.optString("audio")));
            }
        } catch (Exception ignored) {}
        return out;
    }
    public static void save(Context c, ArrayList<Song> songs) {
        JSONArray a = new JSONArray();
        try {
            for (Song s : songs) {
                JSONObject o = new JSONObject();
                o.put("title", s.title); o.put("lyrics", s.lyrics); o.put("audio", s.audioUri == null ? "" : s.audioUri);
                a.put(o);
            }
            c.getSharedPreferences(PREF, 0).edit().putString(KEY, a.toString()).apply();
        } catch (Exception ignored) {}
    }
}
