package mg.aptm.tononkira;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.media.MediaPlayer;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final int PICK_TEXT=10, PICK_AUDIO=11;
    private ArrayList<Song> songs;
    private ArrayAdapter<String> adapter;
    private ListView list;
    private MediaPlayer player;
    private int selected=-1;
    private final int navy=Color.rgb(16,27,53), gold=Color.rgb(213,173,85);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); songs=SongStore.load(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,18,18,12); root.setBackgroundColor(Color.rgb(245,246,249));
        TextView brand=new TextView(this); brand.setText("TONONKIRA A.P.T.M."); brand.setTextSize(25); brand.setTextColor(gold); brand.setGravity(Gravity.CENTER); brand.setPadding(8,22,8,8); brand.setBackgroundColor(navy); root.addView(brand);
        TextView sub=new TextView(this); sub.setText("BOKIN-KIRA • CHORALE"); sub.setTextColor(Color.WHITE); sub.setGravity(Gravity.CENTER); sub.setBackgroundColor(navy); sub.setPadding(8,0,8,18); root.addView(sub);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        addButton(actions,"+ Hira",v->newSong()); addButton(actions,"Import TXT",v->pickText()); addButton(actions,"Audio",v->pickAudio()); root.addView(actions);
        list=new ListView(this); root.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        list.setOnItemClickListener((p,v,pos,id)->showSong(pos));
        refresh(); setContentView(root);
    }
    private void addButton(LinearLayout row,String label,View.OnClickListener l){ Button b=new Button(this); b.setText(label); b.setTextColor(navy); b.setOnClickListener(l); row.addView(b,new LinearLayout.LayoutParams(0,-2,1)); }
    private void refresh(){ ArrayList<String> names=new ArrayList<>(); for(Song s:songs) names.add(s.title); adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,names); list.setAdapter(adapter); }
    private void newSong(){ editSong("","",-1); }
    private void editSong(String title,String lyrics,int index){
        LinearLayout box=new LinearLayout(this); box.setPadding(16,8,16,8); box.setOrientation(LinearLayout.VERTICAL);
        EditText name=new EditText(this); name.setHint("Lohatenin'ny hira"); name.setText(title); box.addView(name);
        EditText body=new EditText(this); body.setHint("Soraty eto ny tononkira"); body.setText(lyrics); body.setMinLines(8); body.setGravity(Gravity.TOP); box.addView(body);
        new AlertDialog.Builder(this).setTitle("Hira").setView(box).setNegativeButton("Hanafoana",null).setPositiveButton("Tehirizo",(d,w)->{
            String n=name.getText().toString().trim(), t=body.getText().toString().trim(); if(n.isEmpty()){Toast.makeText(this,"Ampidiro ny lohateny",Toast.LENGTH_SHORT).show();return;}
            if(index>=0){songs.get(index).title=n;songs.get(index).lyrics=t;}else songs.add(new Song(n,t,"")); SongStore.save(this,songs);refresh();
        }).show();
    }
    private void showSong(int pos){ selected=pos; Song s=songs.get(pos);
        String[] opts={"Vakio / Ovay","Projection","Ampidiro audio","Alefaso audio","Fafao"};
        new AlertDialog.Builder(this).setTitle(s.title).setItems(opts,(d,which)->{
            if(which==0) editSong(s.title,s.lyrics,pos);
            if(which==1){Intent i=new Intent(this,ProjectionActivity.class);i.putExtra("title",s.title);i.putExtra("lyrics",s.lyrics);startActivity(i);}
            if(which==2) pickAudio();
            if(which==3) play(s);
            if(which==4) new AlertDialog.Builder(this).setMessage("Fafàna ity hira ity?").setNegativeButton("Tsia",null).setPositiveButton("Eny",(x,y)->{songs.remove(pos);SongStore.save(this,songs);refresh();}).show();
        }).show();
    }
    private void pickText(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/*");startActivityForResult(i,PICK_TEXT); }
    private void pickAudio(){ if(selected<0){Toast.makeText(this,"Safidio aloha ny hira",Toast.LENGTH_SHORT).show();return;} Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/*");startActivityForResult(i,PICK_AUDIO); }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return; Uri u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        if(req==PICK_TEXT){try(java.io.InputStream in=getContentResolver().openInputStream(u)){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);String text=out.toString("UTF-8");String name=u.getLastPathSegment();songs.add(new Song(name==null?"Hira nafarana":name,text,""));SongStore.save(this,songs);refresh();}catch(Exception e){Toast.makeText(this,"Tsy voavaky ilay rakitra",Toast.LENGTH_LONG).show();}}
        if(req==PICK_AUDIO&&selected>=0){songs.get(selected).audioUri=u.toString();SongStore.save(this,songs);Toast.makeText(this,"Audio nampidirina",Toast.LENGTH_SHORT).show();}
    }
    private void play(Song s){try{if(player!=null){player.release();player=null;}if(s.audioUri==null||s.audioUri.isEmpty()){Toast.makeText(this,"Tsy mbola misy audio amin'ity hira ity",Toast.LENGTH_SHORT).show();return;}player=new MediaPlayer();player.setDataSource(this,Uri.parse(s.audioUri));player.setOnPreparedListener(MediaPlayer::start);player.setOnCompletionListener(mp->{mp.release();player=null;});player.prepareAsync();}catch(Exception e){Toast.makeText(this,"Tsy afaka alefa ilay audio",Toast.LENGTH_SHORT).show();}}
    @Override protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
